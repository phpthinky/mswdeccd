<main class="content-wrapper">

<div class="content-header">
<?=$title?>	
</div>
<div class="content-body">
	<?=$printcontent?>
</div>
</main>