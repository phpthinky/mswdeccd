
                    <!-- The timeline -->
                    <div class="card">  
                      <div class="card-header">
                        Student Nutrition Status
                      </div>
                      <div class="card-body">
                        <table class="table table-bordered">
                          <thead>
                            <tr>

                              <th>#</th>
                              <th>AY</th>
                              <th>Date of weighing</th>
                              <th>Normal</th>
                              <th>Malnourished</th>
                              <th>Obese</th>
                              <th></th>

                            </tr>
                          </thead>
                          <tbody>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <!-- /.timeline -->