            <table class="table ttable-bordered" id="tblSchoolYear">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Status</th>
                  <th></th>
                </tr>
                <tbody>
                  
                </tbody>
              </thead>
            </table>


