<main class="content-wrapper">
  <br/>
  <section class="container-fluid" id="tab-header no-print">
    
  </section>
  <section>
    <div class="print-header">
      <h2>MSWD ECCD Records</h2>
      <label>Date printed: <?=date('M d, Y')?></label>
    </div>
    <?php $this->load->view('eccd-assessment');?>
    
  </section>
</main> 