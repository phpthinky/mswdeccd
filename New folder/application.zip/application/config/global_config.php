<?php 
$config['domain'] = array(
	'gross_motor'=>'Gross Motor',
	'fine_motor'=>'Fine Motor',
	'self_help'=>'Self Help',
	'expressive_lang'=>'Expressive Language',
	'receiptive_lang'=>'Receiptive Language',
	'cognitive'=>'Cognitive',
	'social_emotion'=>'Social Emotional',
	);

 ?>