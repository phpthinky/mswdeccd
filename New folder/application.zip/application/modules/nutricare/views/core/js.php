<!-- OPTIONAL SCRIPTS -->
<script src="<?=base_url('assets')?>/plugins/chart.js/Chart.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?=base_url('assets')?>/dist/js/pages/dashboard3.js"></script>