<div class="card">
	<div class="card-body">
		

		<canvas id="standard-score-chart"></canvas>
	</div>
</div>